package POM_Pages;

import StepDefinietions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class P02_HomePage {

    public WebElement navigationEl()
    {
        return Hooks.driver.findElement(By.id("btnMinifyMe"));
    }

    public WebElement courseEl()
    {
        return Hooks.driver.findElement(By.id("btnMyCoursesList"));
    }

}
