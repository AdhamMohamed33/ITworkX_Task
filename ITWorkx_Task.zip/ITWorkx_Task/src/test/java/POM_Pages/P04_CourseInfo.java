package POM_Pages;

import StepDefinietions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class P04_CourseInfo {
    public WebElement courseNameEl()
    {
        return Hooks.driver.findElement(By.id("txtCourseName"));
    }
    public WebElement courseSubjectEl()
    {
        return Hooks.driver.findElement(By.cssSelector("select > option[label=\"Mathematics\"]"));
    }
    public WebElement courseGradeEl()
    {
        return Hooks.driver.findElement(By.cssSelector("select > option[label=\"4\"]"));
    }
    public WebElement courseTeacherEl()
    {
        return Hooks.driver.findElement(By.cssSelector("i[role=\"button\"]"));
    }
    public WebElement TeachermarkEl()
    {
        return Hooks.driver.findElement(By.id("lblGetSelectedSubjectTeachers"));
    }
    public WebElement teacherChoice()
    {
        return Hooks.driver.findElement(By.cssSelector("input[type=\"search\"]"));
    }


    public WebElement courseCreationEl()
    {
        return Hooks.driver.findElement(By.id("btnSaveAsDraftCourse"));
    }

}
