package POM_Pages;

import StepDefinietions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class P03_CoursePage {

    public WebElement addCourseEl()
    {
        return Hooks.driver.findElement(By.id("btnListAddCourse"));
    }
    public WebElement courseSortingEl()
    {
        return Hooks.driver.findElement(By.cssSelector("select > option[value=\"3\"]"));

    }

    public WebElement assertion()
    {
        return Hooks.driver.findElement(By.cssSelector("a[title=\"Automation Sw Testing Task\"]"));
    }

}


