package POM_Pages;

import StepDefinietions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class P01_LoginPage {

    public WebElement emailEl()
    {
        return Hooks.driver.findElement(By.id("Email"));
    }

    public WebElement passlEl()
    {
        return Hooks.driver.findElement(By.id("inputPassword"));
    }

    public WebElement loginEl()
    {
        return Hooks.driver.findElement(By.id("btnLogin"));
    }


}
