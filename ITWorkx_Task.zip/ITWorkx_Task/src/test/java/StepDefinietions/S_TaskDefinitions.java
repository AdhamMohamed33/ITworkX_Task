package StepDefinietions;

import POM_Pages.P01_LoginPage;
import POM_Pages.P02_HomePage;
import POM_Pages.P03_CoursePage;
import POM_Pages.P04_CourseInfo;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class S_TaskDefinitions {
P01_LoginPage login=new P01_LoginPage();
P02_HomePage home=new P02_HomePage();
P03_CoursePage course_page=new P03_CoursePage();
P04_CourseInfo course_info=new P04_CourseInfo();

@Given("user sign in with username and password")
    public void Signin ()
    {
      login.emailEl().sendKeys("testregister@aaa.com");
      login.passlEl().sendKeys("Wakram_123");
    }
    @And("user click on login button and login successfully")
    public void loginButton (){
      login.loginEl().click();
    }
@And("user open courses Page from left side navigation bar")
    public void coursesPage () {
      home.navigationEl().click();
      home.courseEl().click();
    }

@When("user click on create course button")
    public void courseButton () throws InterruptedException {
       course_page.addCourseEl().click();
        Thread.sleep(1000);
    }

@And("user fill course basic info")
    public void courseInfo ()
    {
     course_info.courseNameEl().sendKeys("Sw Automation Testing Task");
     course_info.courseSubjectEl().click();
     course_info.courseGradeEl().click();
     course_info.TeachermarkEl().click();
   course_info.courseTeacherEl().click();
   course_info.teacherChoice().click();
   course_info.teacherChoice().sendKeys(Keys.ENTER);

    }

@Then("user click on create button")
    public void createButton () throws InterruptedException {

    course_info.courseCreationEl().click();
    Thread.sleep(500);
}

@And("user back to courses list page")
    public void Back_to_Courses_Page ()
   {
       home.navigationEl().click();
       home.courseEl().click();
   }

@And("the course title is displayed")
    public void course_title_display () throws InterruptedException {

     course_page.courseSortingEl().click();
     Thread.sleep(500);
    Hooks.driver.getCurrentUrl();
    String expectedUrl = "https://swinji.azurewebsites.net/Course#!/list/";
    Assert.assertEquals(expectedUrl, Hooks.driver.getCurrentUrl());
   }
}
