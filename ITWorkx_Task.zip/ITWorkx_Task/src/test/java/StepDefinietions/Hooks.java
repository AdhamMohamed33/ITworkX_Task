package StepDefinietions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Hooks {
    // define before and after annotation for your drive

    public static WebDriver driver=null;

    @Before
    public void openBrowser() {
        //1- first step in my code
        String chromepath =System.getProperty("user.dir") + "\\src\\main\\resources\\chromedriver.exe";
        System.setProperty("webdriver.chrome.driver",chromepath);
        //2- new object
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
        //3- navigate to the url
        driver.navigate().to("https://swinji.azurewebsites.net");

    }
    @After
    public void quitBrowser() throws InterruptedException {
        Thread.sleep(2000);
        driver.quit();

    }

}


